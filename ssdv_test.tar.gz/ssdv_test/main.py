from PIL import Image
from io import BytesIO
from subprocess import Popen, PIPE

def run(image_path: str):
    im = Image.open(image_path)
    myio = BytesIO() # new stream
    im.save(myio, format='JPEG')
    myio.seek(0)
    process = Popen(['./ssdv', '-e', '-c', 'ABC123', '-i', '11'], stdin=PIPE, stdout=PIPE, bufsize=-1)
    out, err = process.communicate(input=myio.getvalue())
    myio.close() # close stream
    # print(out)
    print(("Hiba tortent: %" % (err)) if err else "*** Success ***")
    pass

if __name__ == "__main__":
    run(image_path = './resources/test_01.jpg')
